/*
Joshua Murrill
GSP295 week3 lab
7/29/12
Skeleton of main function, MergeSort, Merge, palindromeTest came from chapter 5 and 10.
*/
#include<iostream>
#include<conio.h> //for the pause at the end

using namespace std; //global variable that would be removed when classes installed
int ordercount = 1;  //for the typeTest function at the bottom.
int order = 1;
int x = 0;
int y = 0;




int main()
{
	bool palindrome;  //bool for palindromeTest and typeTest
	char* palinWord;
	char* copyWord;  //wordFlip
	int counter, i = 0;
	

	palinWord = new char;  //set
	copyWord = new char;
	palindrome = true;

	void typeTest(char* palinWord, bool& palindrome);  //function prototypes
	void orderTest(char* palinWord);
	void MergeSort(char* values, int first, int last);
	void Merge(char* values, int leftFirst, int leftLast, int rightFirst, int rightLast);
	void wordFlip(char* palinWord, char*& copyWord, int counter);
	void palindromeTest(char* palinWord, char* copyWord, bool& palindrome, int i);

	cout << "Enter a string to be tested as a palindrome." << endl; //prompt
	cin >> palinWord;
	counter = strlen(palinWord);

	wordFlip(palinWord, copyWord, counter); //was originally thinking it was easiest to flip the word, but
	//then realized later and never got to implement that comparing from both ends would have been better
	palindromeTest(palinWord, copyWord, palindrome, i); //function call for palindrome test
	
	MergeSort(palinWord, i, counter - 1); //sort the string alphabetically
	
	cout << palinWord << endl; //display that mergeSort works

	if(palindrome)
		cout << "String is a palindrome." << endl;
	else
		cout << "String isn't a palindrome." << endl;

	if(palindrome)
		orderTest(palinWord); //only if it is a palindrome will we test for the order

	if(palindrome)
		typeTest(palinWord, palindrome); //only if it is a palindrome we will test for type

	if(palindrome) //use bool to determine type
	{
		cout << "Palindrome is of type 1. There are equal occurences " << endl; 
		cout << "of each letter within the string." << endl;
	}
	else
	{
		cout << "Palindrome is of type 2. The are a different number of occurences " << endl;
		cout << "of each letter within the string." << endl;
	}
	
	
	
	cout << "Please press any key to exit ..." << endl;                           
	cin.sync();                                                                   
	_getch(); 
	return 0;
}

void wordFlip(char* palinWord, char*& copyWord, int counter)  //original thought was to turn the string around and test the first element of each and increment
{
	int j = 0;
	for(int i = 0; i < counter; i++)
	{
		copyWord[(counter - 1) - j] = palinWord[j]; //flip it
		j++;
	}
	copyWord[counter] = NULL;
}

void palindromeTest(char* palinWord, char* copyWord, bool& palindrome, int i)
{
	if(palinWord[i] != copyWord[i])
		palindrome = false;
	if(palinWord[i] != '\n' && palindrome)
	{
		if(palinWord[i] = copyWord[i])
		{
			i++;
			palindromeTest(palinWord, copyWord, palindrome, i);
		}
		if(palinWord[i] != copyWord[i])
			palindrome = false;
	}
}

void Merge(char* values, int leftFirst, int leftLast, int rightFirst, int rightLast)
{
	char* tempArray;
	tempArray = new char;
	int index = leftFirst;
	int saveFirst = leftFirst;

	while((leftFirst <= leftLast) && (rightFirst <= rightLast))
	{
		if(values[leftFirst] < values[rightFirst])
		{
			tempArray[index] = values[leftFirst];
			leftFirst++;
		} 
		else
		{
			tempArray[index] = values[rightFirst];
			rightFirst++;
		}
		 index++;
	}

	while(leftFirst <= leftLast)
	{
		tempArray[index] = values[leftFirst];
		leftFirst++;
		index++;
	}

	while(rightFirst <= rightLast)
	{
		tempArray[index] = values[rightFirst];
		rightFirst++;
		index++;
	}

	for(index = saveFirst; index <= rightLast; index++)
		values[index] = tempArray[index];
}

void MergeSort(char* values, int first, int last)
{
	if(first < last)
	{
		int middle = (first + last) /2;
		MergeSort(values, first, middle);
		MergeSort(values, middle + 1, last);
		Merge(values, first, middle, middle + 1, last); 
	}
}


void orderTest(char* palinWord) //simple comparing of the first set of matching elements to total the order
{
	if(palinWord[0] == palinWord[ordercount])
	{
		order++;
		ordercount++;
		orderTest(palinWord);
	}
	else
	{
		cout << "Palindrome is of order:" << endl;
		cout << order << endl;
	}
}



void typeTest(char* palinWord, bool& palindrome) //very difficult function to determine the type
{
	int counters[25]; //integer array of counters to keep track of the number of each alphabet
	int f = 0; //index
	int i = 0; //index

	for(i = 0; i < 25; i++) //needed to make the array of integers all equal 0
	{                       //dynamic allocation call of new wasnt working out for me
		counters[i] = 0; //haven't though about how to improve this but I know its there
	}

	i = 0; //had to reset these, for if I didn't the would end in the 4k range
	x = 0;
	for(f = 0; f < 25; f++) //loop to check for the amount of intergers in the array
	{                       //actually looking at it now I think I can remove it and it is useless, but will leave it in for it works and no time to fix
		while(palinWord[x] != NULL)  //check whoole string
		{
			if(palinWord[i] == palinWord[x]) ////compare elements
			{
				counters[y] += 1; //if the matched the counter goes
				x++; //check next element
			}
			else
			{
				i = x; //jump to this new letter and compare the following elements
				y++; //change counter in the array for we are counting the total of a different alphabet
				
			}
		}
		
		while(counters[f] != NULL) //check if each counter element matches
		{
			
			while(counters[f] == counters[f + 1]) //keep checking if they match till the end
			{
				palindrome = true;
				f++; //move up the elements
			}
			if(counters[f + 1] == NULL) //need to check if we finished the counters
				return;
			palindrome = false; //false when one counter doesn't match the other
			f++;
		}
	}
}
